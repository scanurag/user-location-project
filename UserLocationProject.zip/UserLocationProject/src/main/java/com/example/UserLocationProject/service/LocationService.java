package com.example.UserLocationProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.UserLocationProject.models.Location;
import com.example.UserLocationProject.repositories.LocationRepository;

import java.util.List;

@Service
public class LocationService {
    @Autowired
    private LocationRepository locationRepository;

    public Location addLocation(Location location){
        return locationRepository.save(location);
    }

    public List<Location> getAllLocation(){
        return locationRepository.findAll();
    }

    public Location getLocation(Long locationId){
        return locationRepository.findById(locationId).isPresent() ? locationRepository.findById(locationId).get() : null;
    }

    public Location updateLocation(Location location){
        return locationRepository.save(location);
    }

    public void deleteLocation(Long locationId){
        locationRepository.delete(getLocation(locationId));
    }
}
