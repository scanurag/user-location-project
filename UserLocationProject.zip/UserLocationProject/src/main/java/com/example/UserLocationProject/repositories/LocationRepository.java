package com.example.UserLocationProject.repositories;
import com.example.UserLocationProject.models.Location;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<Location, Long>{
    
}
