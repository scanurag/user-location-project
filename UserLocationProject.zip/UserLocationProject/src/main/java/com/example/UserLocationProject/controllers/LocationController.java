package com.example.UserLocationProject.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import com.example.UserLocationProject.models.Location;

import org.springframework.http.HttpStatus;
import com.example.UserLocationProject.service.LocationService;

@CrossOrigin
@RestController
@RequestMapping("/api/location")
public class LocationController {
    
    @Autowired
    private LocationService locationService;

    @PostMapping("/")
    public ResponseEntity<?> addLocation(@RequestBody Location location) {
        return ResponseEntity.ok(locationService.addLocation(location));
    }

    @GetMapping("/")
    public ResponseEntity<?> getAllLocation() {
        return ResponseEntity.ok(locationService.getAllLocation());
    }

    @GetMapping("/{LocationId}")
    public ResponseEntity<?> getLocation(@PathVariable Long LocationId) {
        return ResponseEntity.ok(locationService.getLocation(LocationId));
    }

    @PutMapping("/{LocationId}")
    public ResponseEntity<?> updateLocation(@PathVariable Long LocationId, @RequestBody Location location) {
        if (locationService.getLocation(LocationId) != null) {
            return ResponseEntity.ok(locationService.updateLocation(location));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Location with id : " + String.valueOf(LocationId) + ", doesn't exists");
    }

    @DeleteMapping("/{LocationId}")
    public ResponseEntity<?> deleteLocation(@PathVariable Long locationId) {
        locationService.deleteLocation(locationId);
        return ResponseEntity.ok(true);
    }
}
