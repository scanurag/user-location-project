package com.example.UserLocationProject.repositories;

import com.example.UserLocationProject.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, String> {
}
