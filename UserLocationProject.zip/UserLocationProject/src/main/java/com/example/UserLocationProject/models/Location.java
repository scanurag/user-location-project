package com.example.UserLocationProject.models;

import lombok.*;
import javax.persistence.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "locations")
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "location_id")
    private long locId;

    @Column(name = "loc_name")
    private String locationName;
    
    @Column(name = "loc_latitude")
    private String locationLatitude;

    @Column(name = "loc_longitude")
    private String locationLongitude;

}
